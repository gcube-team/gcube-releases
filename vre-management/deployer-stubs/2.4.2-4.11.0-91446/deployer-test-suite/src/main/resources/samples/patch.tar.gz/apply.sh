cp ./foo.txt $GLOBUS_LOCATION/
