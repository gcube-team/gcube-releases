#!/bin/sh
echo $# arguments to $0: $*
java -cp ../tomcat/webapps/wps/WEB-INF/lib/*:../tomcat/lib/*:./*:../wps_algorithms/algorithms/*  org.gcube.dataanalysis.wps.mapper.DataMinerUpdater -a$1 -l../wps_algorithms/algorithms/ -t$2 -i$3 -c../tomcat/webapps/wps/ecocfg/ -s$4 -e$5 -k$6 -u$7 -d$8

