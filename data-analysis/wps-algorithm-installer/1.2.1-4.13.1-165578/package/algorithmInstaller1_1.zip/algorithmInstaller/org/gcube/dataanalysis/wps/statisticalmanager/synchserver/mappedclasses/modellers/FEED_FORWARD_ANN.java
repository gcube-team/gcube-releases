package org.gcube.dataanalysis.wps.statisticalmanager.synchserver.mappedclasses.modellers;
import java.io.File;
import java.net.URL;
import java.io.IOException;
import java.io.InputStream;
import java.util.LinkedHashMap;
import java.io.StringWriter;
import org.apache.commons.io.IOUtils;
import org.apache.xmlbeans.XmlObject;
import org.gcube.dataanalysis.wps.statisticalmanager.synchserver.bindings.*;
import org.n52.wps.algorithm.annotation.*;
import org.n52.wps.io.data.*;
import org.n52.wps.io.data.binding.complex.*;
import org.n52.wps.io.data.binding.literal.*;
import org.n52.wps.server.*;import org.gcube.dataanalysis.wps.statisticalmanager.synchserver.mapping.AbstractEcologicalEngineMapper;import org.n52.wps.server.*;import org.gcube.dataanalysis.wps.statisticalmanager.synchserver.mappedclasses.*;
@Algorithm(statusSupported=true, title="FEED_FORWARD_ANN", abstrakt="A method to train a generic Feed Forward Artifical Neural Network in order to simulate a function from the features space (R^n) to R. Uses the Back-propagation method. Produces a trained neural network in the form of a compiled file which can be used in the FEED FORWARD NEURAL NETWORK DISTRIBUTION algorithm.", identifier="org.gcube.dataanalysis.wps.statisticalmanager.synchserver.mappedclasses.modellers.FEED_FORWARD_ANN", version = "1.1.0")
public class FEED_FORWARD_ANN extends AbstractEcologicalEngineMapper implements IModeller{
@ComplexDataInput(abstrakt="Name of the parameter: TrainingDataSet. a table containing real values colums for training the ANN [a http link to a table in UTF-8 encoding following this template: (GENERIC) A generic comma separated csv file in UTF-8 encoding]", title="a table containing real values colums for training the ANN [a http link to a table in UTF-8 encoding following this template: (GENERIC) A generic comma separated csv file in UTF-8 encoding]", maxOccurs=1, minOccurs=1, identifier = "TrainingDataSet", binding = GenericFileDataBinding.class)	public void setTrainingDataSet(GenericFileData file) {inputs.put("TrainingDataSet",file);}
@LiteralDataInput(abstrakt="Name of the parameter: TrainingColumns. column names to use as features vectors [a sequence of names of columns from TrainingDataSet separated by | ]", defaultValue="", title="column names to use as features vectors [a sequence of names of columns from TrainingDataSet separated by | ]", identifier = "TrainingColumns", maxOccurs=1, minOccurs=1, binding = LiteralStringBinding.class) public void setTrainingColumns(String data) {inputs.put("TrainingColumns",data);}
@LiteralDataInput(abstrakt="Name of the parameter: TargetColumn. the column to use as target [the name of a column from TrainingDataSet]", defaultValue="probability", title="the column to use as target [the name of a column from TrainingDataSet]", identifier = "TargetColumn", maxOccurs=1, minOccurs=1, binding = LiteralStringBinding.class) public void setTargetColumn(String data) {inputs.put("TargetColumn",data);}
@LiteralDataInput(abstrakt="Name of the parameter: LayersNeurons. a list of neurons number for each inner layer [a sequence of values separated by | ] (format: Integer)", defaultValue="", title="a list of neurons number for each inner layer [a sequence of values separated by | ] (format: Integer)", identifier = "LayersNeurons", maxOccurs=1, minOccurs=1, binding = LiteralStringBinding.class) public void setLayersNeurons(String data) {inputs.put("LayersNeurons",data);}
@LiteralDataInput(abstrakt="Name of the parameter: Reference. the phenomenon this ANN is trying to model - can be a generic identifier. Put 1 for not specifying", defaultValue="1", title="the phenomenon this ANN is trying to model - can be a generic identifier. Put 1 for not specifying", identifier = "Reference", maxOccurs=1, minOccurs=1, binding = LiteralStringBinding.class) public void setReference(String data) {inputs.put("Reference",data);}
@LiteralDataInput(abstrakt="Name of the parameter: LearningThreshold. the learning threshold for this ANN", defaultValue="0.01", title="the learning threshold for this ANN", identifier = "LearningThreshold", maxOccurs=1, minOccurs=1, binding = LiteralDoubleBinding.class) public void setLearningThreshold(Double data) {inputs.put("LearningThreshold",""+data);}
@LiteralDataInput(abstrakt="Name of the parameter: MaxIterations. the maximum number of iterations in the training", defaultValue="100", title="the maximum number of iterations in the training", identifier = "MaxIterations", maxOccurs=1, minOccurs=1, binding = LiteralIntBinding.class) public void setMaxIterations(Integer data) {inputs.put("MaxIterations",""+data);}
@LiteralDataInput(abstrakt="Name of the parameter: ModelName. The name of this Neural Network - insert without spaces", defaultValue="neuralnet_", title="The name of this Neural Network - insert without spaces", identifier = "ModelName", maxOccurs=1, minOccurs=1, binding = LiteralStringBinding.class) public void setModelName(String data) {inputs.put("ModelName",data);}
@ComplexDataOutput(abstrakt="Output that is not predetermined", title="NonDeterministicOutput", identifier = "non_deterministic_output", binding = GenericXMLDataBinding.class)
 public XmlObject getNon_deterministic_output() {return (XmlObject) outputs.get("non_deterministic_output");}
@Execute	public void run() throws Exception {		super.run();	} }