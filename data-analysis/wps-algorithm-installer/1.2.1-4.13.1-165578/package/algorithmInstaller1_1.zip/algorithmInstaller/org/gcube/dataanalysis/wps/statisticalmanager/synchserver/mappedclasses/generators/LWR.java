package org.gcube.dataanalysis.wps.statisticalmanager.synchserver.mappedclasses.generators;
import java.io.File;
import java.net.URL;
import java.io.IOException;
import java.io.InputStream;
import java.util.LinkedHashMap;
import java.io.StringWriter;
import org.apache.commons.io.IOUtils;
import org.apache.xmlbeans.XmlObject;
import org.gcube.dataanalysis.wps.statisticalmanager.synchserver.bindings.*;
import org.n52.wps.algorithm.annotation.*;
import org.n52.wps.io.data.*;
import org.n52.wps.io.data.binding.complex.*;
import org.n52.wps.io.data.binding.literal.*;
import org.n52.wps.server.*;import org.gcube.dataanalysis.wps.statisticalmanager.synchserver.mapping.AbstractEcologicalEngineMapper;import org.n52.wps.server.*;import org.gcube.dataanalysis.wps.statisticalmanager.synchserver.mappedclasses.*;
@Algorithm(statusSupported=true, title="LWR", abstrakt="An algorithm to estimate Length-Weight relationship parameters for marine species, using Bayesian methods. Runs an R procedure. Based on the Cube-law theory.", identifier="org.gcube.dataanalysis.wps.statisticalmanager.synchserver.mappedclasses.generators.LWR", version = "1.1.0")
public class LWR extends AbstractEcologicalEngineMapper implements IGenerator{
@ComplexDataInput(abstrakt="Name of the parameter: LWR_Input. Input table containing taxa and species information [a http link to a table in UTF-8 encoding following this template: (GENERIC) A generic comma separated csv file in UTF-8 encoding]", title="Input table containing taxa and species information [a http link to a table in UTF-8 encoding following this template: (GENERIC) A generic comma separated csv file in UTF-8 encoding]", maxOccurs=1, minOccurs=1, identifier = "LWR_Input", binding = GenericFileDataBinding.class)	public void setLWR_Input(GenericFileData file) {inputs.put("LWR_Input",file);}
@LiteralDataInput(abstrakt="Name of the parameter: FamilyColumn. The column containing Family information [the name of a column from LWR_Input]", defaultValue="Family", title="The column containing Family information [the name of a column from LWR_Input]", identifier = "FamilyColumn", maxOccurs=1, minOccurs=1, binding = LiteralStringBinding.class) public void setFamilyColumn(String data) {inputs.put("FamilyColumn",data);}
@LiteralDataInput(abstrakt="Name of the parameter: TableLabel. Name of the table which will contain the model output", defaultValue="lwrout", title="Name of the table which will contain the model output", identifier = "TableLabel", maxOccurs=1, minOccurs=1, binding = LiteralStringBinding.class) public void setTableLabel(String data) {inputs.put("TableLabel",data);}
@ComplexDataOutput(abstrakt="Name of the parameter: OutputTable. Output lwr table [a http link to a table in UTF-8 ecoding following this template: (GENERIC) A generic comma separated csv file in UTF-8 encoding]", title="Output lwr table [a http link to a table in UTF-8 ecoding following this template: (GENERIC) A generic comma separated csv file in UTF-8 encoding]", identifier = "OutputTable", binding = CsvFileDataBinding.class)	public GenericFileData getOutputTable() {URL url=null;try {url = new URL((String) outputs.get("OutputTable")); return new GenericFileData(url.openStream(),"text/csv");} catch (Exception e) {e.printStackTrace();return null;}}
@ComplexDataOutput(abstrakt="Output that is not predetermined", title="NonDeterministicOutput", identifier = "non_deterministic_output", binding = GenericXMLDataBinding.class)
 public XmlObject getNon_deterministic_output() {return (XmlObject) outputs.get("non_deterministic_output");}
@Execute	public void run() throws Exception {		super.run();	} }