package org.gcube.dataanalysis.wps.statisticalmanager.synchserver.mappedclasses.modellers;
import java.io.File;
import java.net.URL;
import java.io.IOException;
import java.io.InputStream;
import java.util.LinkedHashMap;
import java.io.StringWriter;
import org.apache.commons.io.IOUtils;
import org.apache.xmlbeans.XmlObject;
import org.gcube.dataanalysis.wps.statisticalmanager.synchserver.bindings.*;
import org.n52.wps.algorithm.annotation.*;
import org.n52.wps.io.data.*;
import org.n52.wps.io.data.binding.complex.*;
import org.n52.wps.io.data.binding.literal.*;
import org.n52.wps.server.*;import org.gcube.dataanalysis.wps.statisticalmanager.synchserver.mapping.AbstractEcologicalEngineMapper;import org.n52.wps.server.*;import org.gcube.dataanalysis.wps.statisticalmanager.synchserver.mappedclasses.*;
@Algorithm(statusSupported=true, title="AQUAMAPSNN", abstrakt="The AquaMaps model trained using a Feed Forward Neural Network. This is a method to train a generic Feed Forward Artifical Neural Network to be used by the AquaMaps Neural Network algorithm. Produces a trained neural network in the form of a compiled file which can be used later.", identifier="org.gcube.dataanalysis.wps.statisticalmanager.synchserver.mappedclasses.modellers.AQUAMAPSNN", version = "1.1.0")
public class AQUAMAPSNN extends AbstractEcologicalEngineMapper implements IModeller{
@ComplexDataInput(abstrakt="Name of the parameter: AbsenceDataTable. A Table containing absence points [a http link to a table in UTF-8 encoding following this template: (HCAF) http://goo.gl/SZG9uM]", title="A Table containing absence points [a http link to a table in UTF-8 encoding following this template: (HCAF) http://goo.gl/SZG9uM]", maxOccurs=1, minOccurs=1, identifier = "AbsenceDataTable", binding = GenericFileDataBinding.class)	public void setAbsenceDataTable(GenericFileData file) {inputs.put("AbsenceDataTable",file);}
@ComplexDataInput(abstrakt="Name of the parameter: PresenceDataTable. A Table containing positive occurrences [a http link to a table in UTF-8 encoding following this template: (HCAF) http://goo.gl/SZG9uM]", title="A Table containing positive occurrences [a http link to a table in UTF-8 encoding following this template: (HCAF) http://goo.gl/SZG9uM]", maxOccurs=1, minOccurs=1, identifier = "PresenceDataTable", binding = GenericFileDataBinding.class)	public void setPresenceDataTable(GenericFileData file) {inputs.put("PresenceDataTable",file);}
@LiteralDataInput(abstrakt="Name of the parameter: SpeciesName. Species Code of the fish the NN will correspond to", defaultValue="Fis-30189", title="Species Code of the fish the NN will correspond to", identifier = "SpeciesName", maxOccurs=1, minOccurs=1, binding = LiteralStringBinding.class) public void setSpeciesName(String data) {inputs.put("SpeciesName",data);}
@LiteralDataInput(abstrakt="Name of the parameter: LayersNeurons. a list of neurons number for each inner layer [a sequence of values separated by | ] (format: Integer)", defaultValue="", title="a list of neurons number for each inner layer [a sequence of values separated by | ] (format: Integer)", identifier = "LayersNeurons", maxOccurs=1, minOccurs=1, binding = LiteralStringBinding.class) public void setLayersNeurons(String data) {inputs.put("LayersNeurons",data);}
@LiteralDataInput(abstrakt="Name of the parameter: NeuralNetworkName. The name of this Neural Network - insert without spaces", defaultValue="neuralnet_", title="The name of this Neural Network - insert without spaces", identifier = "NeuralNetworkName", maxOccurs=1, minOccurs=1, binding = LiteralStringBinding.class) public void setNeuralNetworkName(String data) {inputs.put("NeuralNetworkName",data);}
@ComplexDataOutput(abstrakt="Output that is not predetermined", title="NonDeterministicOutput", identifier = "non_deterministic_output", binding = GenericXMLDataBinding.class)
 public XmlObject getNon_deterministic_output() {return (XmlObject) outputs.get("non_deterministic_output");}
@Execute	public void run() throws Exception {		super.run();	} }