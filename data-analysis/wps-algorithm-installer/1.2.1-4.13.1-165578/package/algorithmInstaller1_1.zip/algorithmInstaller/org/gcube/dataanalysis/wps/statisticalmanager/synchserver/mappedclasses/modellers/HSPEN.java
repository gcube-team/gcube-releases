package org.gcube.dataanalysis.wps.statisticalmanager.synchserver.mappedclasses.modellers;
import java.io.File;
import java.net.URL;
import java.io.IOException;
import java.io.InputStream;
import java.util.LinkedHashMap;
import java.io.StringWriter;
import org.apache.commons.io.IOUtils;
import org.apache.xmlbeans.XmlObject;
import org.gcube.dataanalysis.wps.statisticalmanager.synchserver.bindings.*;
import org.n52.wps.algorithm.annotation.*;
import org.n52.wps.io.data.*;
import org.n52.wps.io.data.binding.complex.*;
import org.n52.wps.io.data.binding.literal.*;
import org.n52.wps.server.*;import org.gcube.dataanalysis.wps.statisticalmanager.synchserver.mapping.AbstractEcologicalEngineMapper;import org.n52.wps.server.*;import org.gcube.dataanalysis.wps.statisticalmanager.synchserver.mappedclasses.*;
@Algorithm(statusSupported=true, title="HSPEN", abstrakt="The AquMaps HSPEN algorithm. A modeling algorithm that generates a table containing species envelops (HSPEN), i.e. models capturing species tolerance with respect to environmental parameters, to be used by the AquaMaps approach.", identifier="org.gcube.dataanalysis.wps.statisticalmanager.synchserver.mappedclasses.modellers.HSPEN", version = "1.1.0")
public class HSPEN extends AbstractEcologicalEngineMapper implements IModeller{
@ComplexDataInput(abstrakt="Name of the parameter: EnvelopeTable. The previous hspen table for regeneration [a http link to a table in UTF-8 encoding following this template: (HSPEN) http://goo.gl/4zDiAK]", title="The previous hspen table for regeneration [a http link to a table in UTF-8 encoding following this template: (HSPEN) http://goo.gl/4zDiAK]", maxOccurs=1, minOccurs=1, identifier = "EnvelopeTable", binding = GenericFileDataBinding.class)	public void setEnvelopeTable(GenericFileData file) {inputs.put("EnvelopeTable",file);}
@ComplexDataInput(abstrakt="Name of the parameter: CsquarecodesTable. HCaf Table [a http link to a table in UTF-8 encoding following this template: (HCAF) http://goo.gl/SZG9uM]", title="HCaf Table [a http link to a table in UTF-8 encoding following this template: (HCAF) http://goo.gl/SZG9uM]", maxOccurs=1, minOccurs=1, identifier = "CsquarecodesTable", binding = GenericFileDataBinding.class)	public void setCsquarecodesTable(GenericFileData file) {inputs.put("CsquarecodesTable",file);}
@ComplexDataInput(abstrakt="Name of the parameter: OccurrenceCellsTable. Ocurrence Cells Table [a http link to a table in UTF-8 encoding following this template: (OCCURRENCE_AQUAMAPS) http://goo.gl/vHil5T]", title="Ocurrence Cells Table [a http link to a table in UTF-8 encoding following this template: (OCCURRENCE_AQUAMAPS) http://goo.gl/vHil5T]", maxOccurs=1, minOccurs=1, identifier = "OccurrenceCellsTable", binding = GenericFileDataBinding.class)	public void setOccurrenceCellsTable(GenericFileData file) {inputs.put("OccurrenceCellsTable",file);}
@LiteralDataInput(abstrakt="Name of the parameter: OuputEnvelopeTableLabel. Table name for the new hspen", defaultValue="hspen_1", title="Table name for the new hspen", identifier = "OuputEnvelopeTableLabel", maxOccurs=1, minOccurs=1, binding = LiteralStringBinding.class) public void setOuputEnvelopeTableLabel(String data) {inputs.put("OuputEnvelopeTableLabel",data);}
@ComplexDataOutput(abstrakt="Name of the parameter: OutputTable. Output hspen table [a http link to a table in UTF-8 ecoding following this template: (HSPEN) http://goo.gl/4zDiAK]", title="Output hspen table [a http link to a table in UTF-8 ecoding following this template: (HSPEN) http://goo.gl/4zDiAK]", identifier = "OutputTable", binding = CsvFileDataBinding.class)	public GenericFileData getOutputTable() {URL url=null;try {url = new URL((String) outputs.get("OutputTable")); return new GenericFileData(url.openStream(),"text/csv");} catch (Exception e) {e.printStackTrace();return null;}}
@ComplexDataOutput(abstrakt="Output that is not predetermined", title="NonDeterministicOutput", identifier = "non_deterministic_output", binding = GenericXMLDataBinding.class)
 public XmlObject getNon_deterministic_output() {return (XmlObject) outputs.get("non_deterministic_output");}
@Execute	public void run() throws Exception {		super.run();	} }