package org.gcube.dataanalysis.wps.statisticalmanager.synchserver.mappedclasses.generators;
import java.io.File;
import java.net.URL;
import java.io.IOException;
import java.io.InputStream;
import java.util.LinkedHashMap;
import java.io.StringWriter;
import org.apache.commons.io.IOUtils;
import org.apache.xmlbeans.XmlObject;
import org.gcube.dataanalysis.wps.statisticalmanager.synchserver.bindings.*;
import org.n52.wps.algorithm.annotation.*;
import org.n52.wps.io.data.*;
import org.n52.wps.io.data.binding.complex.*;
import org.n52.wps.io.data.binding.literal.*;
import org.n52.wps.server.*;import org.gcube.dataanalysis.wps.statisticalmanager.synchserver.mapping.AbstractEcologicalEngineMapper;import org.n52.wps.server.*;import org.gcube.dataanalysis.wps.statisticalmanager.synchserver.mappedclasses.*;
@Algorithm(statusSupported=true, title="FEED_FORWARD_A_N_N_DISTRIBUTION", abstrakt="A Bayesian method using a Feed Forward Neural Network to simulate a function from the features space (R^n) to R. A modeling algorithm that relies on Neural Networks to simulate a real valued function. It accepts as input a table containing the training dataset and some parameters affecting the algorithm behaviour such as the number of neurons, the learning threshold and the maximum number of iterations.", identifier="org.gcube.dataanalysis.wps.statisticalmanager.synchserver.mappedclasses.generators.FEED_FORWARD_A_N_N_DISTRIBUTION", version = "1.1.0")
public class FEED_FORWARD_A_N_N_DISTRIBUTION extends AbstractEcologicalEngineMapper implements IGenerator{
@ComplexDataInput(abstrakt="Name of the parameter: FeaturesTable. a Table containing features vectors [a http link to a table in UTF-8 encoding following this template: (GENERIC) A generic comma separated csv file in UTF-8 encoding]", title="a Table containing features vectors [a http link to a table in UTF-8 encoding following this template: (GENERIC) A generic comma separated csv file in UTF-8 encoding]", maxOccurs=1, minOccurs=1, identifier = "FeaturesTable", binding = GenericFileDataBinding.class)	public void setFeaturesTable(GenericFileData file) {inputs.put("FeaturesTable",file);}
@LiteralDataInput(abstrakt="Name of the parameter: FeaturesColumnNames. column names of the features [a sequence of names of columns from FeaturesTable separated by | ]", defaultValue="", title="column names of the features [a sequence of names of columns from FeaturesTable separated by | ]", identifier = "FeaturesColumnNames", maxOccurs=1, minOccurs=1, binding = LiteralStringBinding.class) public void setFeaturesColumnNames(String data) {inputs.put("FeaturesColumnNames",data);}
@LiteralDataInput(abstrakt="Name of the parameter: FinalTableLabel. table name of the resulting distribution", defaultValue="Distrib_", title="table name of the resulting distribution", identifier = "FinalTableLabel", maxOccurs=1, minOccurs=1, binding = LiteralStringBinding.class) public void setFinalTableLabel(String data) {inputs.put("FinalTableLabel",data);}
@LiteralDataInput(abstrakt="Name of the parameter: GroupingFactor. identifier for grouping sets of vectors (blank for automatic enum)", defaultValue="speciesid", title="identifier for grouping sets of vectors (blank for automatic enum)", identifier = "GroupingFactor", maxOccurs=1, minOccurs=1, binding = LiteralStringBinding.class) public void setGroupingFactor(String data) {inputs.put("GroupingFactor",data);}
@ComplexDataInput(abstrakt="Name of the parameter: ModelName. neuralnet_", title="neuralnet_", maxOccurs=1, minOccurs=1, identifier = "ModelName", binding = D4ScienceDataInputBinding.class)	public void setModelName(GenericFileData file) {inputs.put("ModelName",file);}
@ComplexDataOutput(abstrakt="Name of the parameter: OutputTable. Output table [a http link to a table in UTF-8 ecoding following this template: (TESTSET) http://goo.gl/LZHNXt]", title="Output table [a http link to a table in UTF-8 ecoding following this template: (TESTSET) http://goo.gl/LZHNXt]", identifier = "OutputTable", binding = CsvFileDataBinding.class)	public GenericFileData getOutputTable() {URL url=null;try {url = new URL((String) outputs.get("OutputTable")); return new GenericFileData(url.openStream(),"text/csv");} catch (Exception e) {e.printStackTrace();return null;}}
@ComplexDataOutput(abstrakt="Output that is not predetermined", title="NonDeterministicOutput", identifier = "non_deterministic_output", binding = GenericXMLDataBinding.class)
 public XmlObject getNon_deterministic_output() {return (XmlObject) outputs.get("non_deterministic_output");}
@Execute	public void run() throws Exception {		super.run();	} }