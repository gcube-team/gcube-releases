package org.gcube.dataanalysis.wps.statisticalmanager.synchserver.mappedclasses.generators;
import java.io.File;
import java.net.URL;
import java.io.IOException;
import java.io.InputStream;
import java.util.LinkedHashMap;
import java.io.StringWriter;
import org.apache.commons.io.IOUtils;
import org.apache.xmlbeans.XmlObject;
import org.gcube.dataanalysis.wps.statisticalmanager.synchserver.bindings.*;
import org.n52.wps.algorithm.annotation.*;
import org.n52.wps.io.data.*;
import org.n52.wps.io.data.binding.complex.*;
import org.n52.wps.io.data.binding.literal.*;
import org.n52.wps.server.*;import org.gcube.dataanalysis.wps.statisticalmanager.synchserver.mapping.AbstractEcologicalEngineMapper;import org.n52.wps.server.*;import org.gcube.dataanalysis.wps.statisticalmanager.synchserver.mappedclasses.*;
@Algorithm(statusSupported=true, title="AQUAMAPS_NATIVE_2050", abstrakt="Algorithm for Native 2050 Distribution by AquaMaps. A distribution algorithm that generates a table containing  species distribution probabilities on half-degree cells according to the AquaMaps approach with native distribution estimated for 2050.", identifier="org.gcube.dataanalysis.wps.statisticalmanager.synchserver.mappedclasses.generators.AQUAMAPS_NATIVE_2050", version = "1.1.0")
public class AQUAMAPS_NATIVE_2050 extends AbstractEcologicalEngineMapper implements IGenerator{
@ComplexDataInput(abstrakt="Name of the parameter: EnvelopeTable. The previous hspen table for regeneration [a http link to a table in UTF-8 encoding following this template: (HSPEN) http://goo.gl/4zDiAK]", title="The previous hspen table for regeneration [a http link to a table in UTF-8 encoding following this template: (HSPEN) http://goo.gl/4zDiAK]", maxOccurs=1, minOccurs=1, identifier = "EnvelopeTable", binding = GenericFileDataBinding.class)	public void setEnvelopeTable(GenericFileData file) {inputs.put("EnvelopeTable",file);}
@ComplexDataInput(abstrakt="Name of the parameter: CsquarecodesTable. HCaf Table [a http link to a table in UTF-8 encoding following this template: (HCAF) http://goo.gl/SZG9uM]", title="HCaf Table [a http link to a table in UTF-8 encoding following this template: (HCAF) http://goo.gl/SZG9uM]", maxOccurs=1, minOccurs=1, identifier = "CsquarecodesTable", binding = GenericFileDataBinding.class)	public void setCsquarecodesTable(GenericFileData file) {inputs.put("CsquarecodesTable",file);}
@LiteralDataInput(abstrakt="Name of the parameter: DistributionTableLabel. Name of the HSPEC probability distribution", defaultValue="hspec", title="Name of the HSPEC probability distribution", identifier = "DistributionTableLabel", maxOccurs=1, minOccurs=1, binding = LiteralStringBinding.class) public void setDistributionTableLabel(String data) {inputs.put("DistributionTableLabel",data);}
@ComplexDataInput(abstrakt="Name of the parameter: OccurrencePointsTable. The Occurrence points table for calculating the bounding box [a http link to a table in UTF-8 encoding following this template: (OCCURRENCE_AQUAMAPS) http://goo.gl/vHil5T]", title="The Occurrence points table for calculating the bounding box [a http link to a table in UTF-8 encoding following this template: (OCCURRENCE_AQUAMAPS) http://goo.gl/vHil5T]", maxOccurs=1, minOccurs=1, identifier = "OccurrencePointsTable", binding = GenericFileDataBinding.class)	public void setOccurrencePointsTable(GenericFileData file) {inputs.put("OccurrencePointsTable",file);}
@ComplexDataOutput(abstrakt="Name of the parameter: OutputTable. Output hspec table [a http link to a table in UTF-8 ecoding following this template: (HSPEC) http://goo.gl/OvKa1h]", title="Output hspec table [a http link to a table in UTF-8 ecoding following this template: (HSPEC) http://goo.gl/OvKa1h]", identifier = "OutputTable", binding = CsvFileDataBinding.class)	public GenericFileData getOutputTable() {URL url=null;try {url = new URL((String) outputs.get("OutputTable")); return new GenericFileData(url.openStream(),"text/csv");} catch (Exception e) {e.printStackTrace();return null;}}
@ComplexDataOutput(abstrakt="Output that is not predetermined", title="NonDeterministicOutput", identifier = "non_deterministic_output", binding = GenericXMLDataBinding.class)
 public XmlObject getNon_deterministic_output() {return (XmlObject) outputs.get("non_deterministic_output");}
@Execute	public void run() throws Exception {		super.run();	} }