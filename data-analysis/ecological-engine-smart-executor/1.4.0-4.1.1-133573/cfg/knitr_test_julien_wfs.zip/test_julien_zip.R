# Rapport Julien
require(IndicatorsForFisheries)
# Rapport Taha
require(repmis)
require(rworldmap)
require(pryr)
require(plotly)
# Rapport Taha => nécessite package media9.sty pour Latex



#Specify the working directory
# mywd <- '~/SVNs/GIT/IRDTunaAtlas/'
# setwd(mywd)
